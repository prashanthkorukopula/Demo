({
	doInit : function(component, event, helper) {
        component.set('v.columns',[{label : 'Account Name',fieldName : 'Name', type : 'text'},
                                   {label:'Industry',fieldName : 'Industry' ,type : 'text'},
                                   {label : 'Type',fieldName : 'Type',Type : 'text'}]);
		var action = component.get('c.getAccounts');
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === 'SUCCESS'){
                var data = response.getReturnValue();
                var xyz = component.get('v.sortedBy');
                console.log('xyz-->',xyz);
                var abc = component.get('v.sortedDirection');
                console.log('abc-->',abc);
                console.log('data-->',data);
                component.set('v.accounts',data);
                helper.sortData(component, xyz, abc);
            }else{
                alert(state);
                console.log('ERROR :',state);
            }
            
        });
        $A.enqueueAction(action);
	},
     updateColumnSorting: function (cmp, event, helper) {
        var fieldName = event.getParam('fieldName');
         console.log('fieldName-->',fieldName);
        var sortDirection = event.getParam('sortDirection');
         console.log('sortDirection-->',sortDirection);
        cmp.set("v.sortedBy", fieldName);
        cmp.set("v.sortedDirection", sortDirection);
        helper.sortData(cmp, fieldName, sortDirection);
    }
})