({
	callServer : function(component,method,callback,params) {
        var action = component.get(method);
        if (params) {
            action.setParams(params);
        }
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                // pass returned value to callback function
                callback.call(this,response.getReturnValue());
            } else if (state === "ERROR") {
                // generic error handler
                var errors = response.getError();
                if (errors) {
                    console.log("Errors", errors);
                    if (errors[0] && errors[0].message) {
                        throw new Error("Error" + errors[0].message);
                    }
                } else {
                    throw new Error("Unknown Error");
                }
            }
        });
        
        $A.enqueueAction(action);
    },
    fetchPickListValues : function(component) {
		this.callServer(
		component,
		'c.getFieldPickList',
		function(result){
			if(result != null && result.length > 0){
				var pickListvalues = [];
				for(var key in result){
					pickListvalues.push({value:result[key],key:key});
				}
				component.set("v.values",pickListvalues);
			}
		},
		{ObjectApiName: component.get("v.objectName"),pickListField:component.get("v.fldName")}
		);
	},
    fetchAllFields : function(component) {
		this.callServer(
		component,
		'c.getAllFields',
		function(result){
			if(result != null && result.length > 0){
				var fields = [];
				for(var key in result){
					fields.push({value:result[key],key:key});
				}
				component.set("v.lstFields",fields);
			}
		},
		{ObjectApiName: component.get("v.objectName"),recordId: component.get("v.recordId")}
		);
	}
})