({
	clickCreateItem : function(component, event, helper) {
        var validitem = component.find('itemform').reduce(function(validSoFar, inputCmp){
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        },true);
        
        if(validitem){
            var newitem = component.get("v.newItem");
            
            helper.createItem(component,newitem);
        }
	},
    doInit : function(component,event,helper){
    	//createing the server request
    	var action = component.get("c.getItems");
    	action.setCallback(this,function(response){
		 	var state = response.getState(); 
            if(state === "SUCCESS"){
                console.log('items-->',response.getReturnValue());
            	component.set("v.items",response.getReturnValue());
            }else{
                console.log('error :',state);
            }
		});
        $A.enqueueAction(action);
	},
})