({
	createItem : function(component,item) {
        //create the server request
		var action = component.get("c.saveItem");
        action.setParams({
            "item": item
        });
        console.log('item-->');
        action.setCallback(this,function(response){
            console.log('item1-->');
            var state = response.getState();
            if(state === "SUCCESS"){
                console.log('itemsuccess-->');
               var items1 = component.get("v.items");
                console.log('items1:',items1);
                items1.push(response.getReturnValue());
                console.log('rsponse-->',response.getReturnValue());
                component.set("v.items",items1);
            }else{
                console.log('erroe :',state);
            }
        });
        $A.enqueueAction(action);
	},
})