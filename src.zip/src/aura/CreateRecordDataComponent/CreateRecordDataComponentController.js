({
	handleCreate : function(component, event, helper) {
        var createEvent = $A.get("e.force:createRecord");
        if(createEvent){
            createEvent.setParams({
                'entityApiName':'Contact'
            });
            createEvent.fire();
        }else{
            alert('create unsuccessful');
        }
	}
})