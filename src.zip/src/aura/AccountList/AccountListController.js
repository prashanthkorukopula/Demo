({
	doInit : function(component, event, helper) {
		var action = component.get("c.getAccounts");
        action.setCallback(this,function(response){
        	var state = response.getState();
            console.log('state-->',state);
            if(state === 'SUCCESS'){
                	var data = response.getReturnValue();
                	console.log('data-->',data);
                	component.set("v.accounts",data);
            }else{
                alert(state);
                console.log('Error :',state);
            }
        });
        $A.enqueueAction(action);
	},
    navigateToAccount : function (component,event){
        var recId = event.target.getAttribute("data-Id");
        console.log('ev-->',event.target.getAttribute("data-Id"));
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": recId,
            "slideDevName": "detail"
        });
        navEvt.fire();
    },
    onDelete : function(component,event,helper){
        var index = event.getSource().get("v.value");
        console.log('id--->',index);
        var accList = component.get("v.accounts");
        console.log('accrecs-->',accList);
        accList.splice(index,1);
        component.set("v.accounts",accList);
        
    },
    onEdit : function(component,event,helper){
        var recId = event.getSource().get("v.value");
        console.log('recid-->',recId);
        var navEve = $A.get("e.force:editRecord");
        navEve.setParams({
            "recordId" : recId 
        });
        navEve.fire();
    },
    onView : function (component,event,helper){
        var recId = event.getSource().get("v.value");
        console.log('rcid-->',recId);
        var viewEvt = $A.get("e.force:navigateToURL");
        viewEvt.setParams({
            "url" : "/"+recId
        });
        viewEvt.fire();
    },
})