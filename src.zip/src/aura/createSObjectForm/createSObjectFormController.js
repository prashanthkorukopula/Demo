({
    handleSubmit : function(component, event, helper) {
        event.preventDefault(); // Prevent default submit
        var fields = event.getParam("fields");
        fields["Description"] = 'This is a default description'; // Prepopulate Description field
        component.find('createAccountForm').submit(fields); // Submit form
    }
})