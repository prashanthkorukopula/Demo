({
    createExpense: function(component, expense) {
        var action = component.get("c.saveExpense");
        console.log('action-->',action);
        action.setParams({
            "expense":expense
        });
        console.log("expense-->",expense);
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var expenses = component.get("v.expenses");
                console.log("expenses---:",expenses);
                expenses.push(response.getReturnValue());
                console.log("expenses1---:",expenses);
                component.set("v.expenses",expenses);
            }else{
                console.log("error :",state);
            }
        });
        $A.enqueueAction(action);
    },
})