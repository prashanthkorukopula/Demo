({
	clickCreate : function(component, event, helper) {
        var validExpense = component.find('expenseform').reduce(function(validSoFar, inputCmp){
            //display error message fo invalid fields
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        },true);
        //if we pass error checking ,do some real work
        if(validExpense){
            //create the new expense
            var newExpense = component.get("v.newExpense");
            //console.log("create expense:"+JSON.Stringify(newExpense));
            helper.createExpense(component,newExpense);
        }
	},
    doInit : function(component, event, helper) {
        //creating the server request
        
       var action = component.get("c.getExpenses");
        
        //handle server response
        
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                component.set("v.expenses",response.getReturnValue());
                console.log('records-->',response.getReturnValue());
            }else{
                console.log("failed with state : "+state);
            }
        });
        
        //sending server request
        $A.enqueueAction(action);
    },
})