({
    packItem : function(component, event, helper) {
        var var1  = component.get("v.item",true);
        var1.Packed__c = true;
        var button = event.getSource();
		component.set("v.item",var1);
        button.set("v.disabled",true);
	}
})