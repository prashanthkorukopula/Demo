({
	myAction : function(component, event, helper) {
        component.set("v.columns", [
        {label:"First Name", fieldName:"FirstName", type:"text"},
        {label:"Last Name", fieldName:"LastName", type:"text"},
        {label:"Phone", fieldName:"Phone", type:"phone"}
		]);

		var action = component.get("c.getContacts");
        action.setParams({
            recordId : component.get("v.recordId")
        });
        action.setCallback(this,function(data){
            var state = data.getState();
            if(state === "SUCCESS"){
                component.set("v.contacts",data.getReturnValue());
                console.log("data :",data.getReturnValue());
            }else{
                console.log("Error :",state);
            }
        });
        $A.enqueueAction(action);
	}
})