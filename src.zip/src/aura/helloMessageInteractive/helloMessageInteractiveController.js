({
    handleClick : function(component, event, handler) {
    	var var1 = event.getSource(); //button
        var var2 = var1.get("v.label") // button's label
        component.set("v.message",var2);
	}
})