({
	doInit : function(component, event, helper) {
		//prepare a new record from template
		
	}
})